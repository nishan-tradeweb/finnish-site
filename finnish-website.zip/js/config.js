/* finnish website settings.
   1) DOWNLOAD LINKS: paste each direct download link between the quotes. A button with an empty link
      shows "Download link coming soon" when tapped.
   (Mac and iPhone open the web version until the store links exist. Replace them with the store links later.)
   2) PRICES: the same six-tier price ladder as the app. One price per country on every platform.
      India is 25 a month and 200 a year. Any country not listed is tier 4 (2 a month, 20 a year). */
window.FINNISH_CONFIG = {
  mobilePrices: {},
  annual: { mobile: { US: 50, CA: 50, AU: 50, NZ: 50, CH: 50, JP: 50, SG: 50, IE: 50, NL: 50, BE: 50, LU: 50, FR: 50, FI: 50, DK: 50, SE: 50, NO: 50, IS: 50, AT: 50, DE: 50, GB: 50, ES: 40, IT: 40, PT: 40, KR: 40, IL: 40, AE: 40, SA: 40, QA: 40, KW: 40, BH: 40, OM: 40, HK: 40, TW: 40, CY: 40, MT: 40, SI: 40, EE: 40, SK: 40, LT: 40, LV: 40, CZ: 40, PL: 30, HU: 30, HR: 30, GR: 30, RO: 30, BG: 30, CL: 30, UY: 30, CR: 30, PA: 30, MY: 30, MX: 30, KZ: 30, RS: 30, BR: 20, CO: 20, AR: 20, PE: 20, EC: 20, DO: 20, TH: 20, CN: 20, ZA: 20, UA: 20, GE: 20, AM: 20, AZ: 20, MK: 20, VN: 10, PH: 10, ID: 10, LK: 10, KE: 10, TZ: 10, UG: 10, TR: 10, EG: 10, JO: 10, TN: 10, DZ: 10, NP: 10, KH: 10, LA: 10, MM: 10, UZ: 10, GH: 10, ZM: 10, SN: 10, CI: 10, CM: 10, PK: 4, BD: 4, NG: 4, IN: 200 }, desktop: { US: 50, CA: 50, AU: 50, NZ: 50, CH: 50, JP: 50, SG: 50, IE: 50, NL: 50, BE: 50, LU: 50, FR: 50, FI: 50, DK: 50, SE: 50, NO: 50, IS: 50, AT: 50, DE: 50, GB: 50, ES: 40, IT: 40, PT: 40, KR: 40, IL: 40, AE: 40, SA: 40, QA: 40, KW: 40, BH: 40, OM: 40, HK: 40, TW: 40, CY: 40, MT: 40, SI: 40, EE: 40, SK: 40, LT: 40, LV: 40, CZ: 40, PL: 30, HU: 30, HR: 30, GR: 30, RO: 30, BG: 30, CL: 30, UY: 30, CR: 30, PA: 30, MY: 30, MX: 30, KZ: 30, RS: 30, BR: 20, CO: 20, AR: 20, PE: 20, EC: 20, DO: 20, TH: 20, CN: 20, ZA: 20, UA: 20, GE: 20, AM: 20, AZ: 20, MK: 20, VN: 10, PH: 10, ID: 10, LK: 10, KE: 10, TZ: 10, UG: 10, TR: 10, EG: 10, JO: 10, TN: 10, DZ: 10, NP: 10, KH: 10, LA: 10, MM: 10, UZ: 10, GH: 10, ZM: 10, SN: 10, CI: 10, CM: 10, PK: 4, BD: 4, NG: 4, IN: 200 } },
  annualMultiple: { mobile: 10, desktop: 10 },
  links: {
    android: "",
    ios: "https://nishan-tradeweb.github.io/finnish-app/",
    windows: "",
    mac: "https://nishan-tradeweb.github.io/finnish-app/",
    linux: ""
  },
  trialDays: 5,
  fallback: ["US", "International", "USD", 5],
  unlisted: ["USD", 2, 20],
  prices: {
    US: ["US", "USD", 5], CA: ["CA", "USD", 5], AU: ["AU", "USD", 5], NZ: ["NZ", "USD", 5],
    CH: ["CH", "USD", 5], JP: ["JP", "USD", 5], SG: ["SG", "USD", 5], IE: ["IE", "EUR", 5],
    NL: ["NL", "EUR", 5], BE: ["BE", "EUR", 5], LU: ["LU", "EUR", 5], FR: ["FR", "EUR", 5],
    FI: ["FI", "EUR", 5], DK: ["DK", "USD", 5], SE: ["SE", "USD", 5], NO: ["NO", "USD", 5],
    IS: ["IS", "USD", 5], AT: ["AT", "EUR", 5], DE: ["DE", "EUR", 5], GB: ["GB", "GBP", 5],
    ES: ["ES", "USD", 4], IT: ["IT", "USD", 4], PT: ["PT", "USD", 4], KR: ["KR", "USD", 4],
    IL: ["IL", "USD", 4], AE: ["AE", "USD", 4], SA: ["SA", "USD", 4], QA: ["QA", "USD", 4],
    KW: ["KW", "USD", 4], BH: ["BH", "USD", 4], OM: ["OM", "USD", 4], HK: ["HK", "USD", 4],
    TW: ["TW", "USD", 4], CY: ["CY", "USD", 4], MT: ["MT", "USD", 4], SI: ["SI", "USD", 4],
    EE: ["EE", "USD", 4], SK: ["SK", "USD", 4], LT: ["LT", "USD", 4], LV: ["LV", "USD", 4],
    CZ: ["CZ", "USD", 4], PL: ["PL", "USD", 3], HU: ["HU", "USD", 3], HR: ["HR", "USD", 3],
    GR: ["GR", "USD", 3], RO: ["RO", "USD", 3], BG: ["BG", "USD", 3], CL: ["CL", "USD", 3],
    UY: ["UY", "USD", 3], CR: ["CR", "USD", 3], PA: ["PA", "USD", 3], MY: ["MY", "USD", 3],
    MX: ["MX", "USD", 3], KZ: ["KZ", "USD", 3], RS: ["RS", "USD", 3], BR: ["BR", "USD", 2],
    CO: ["CO", "USD", 2], AR: ["AR", "USD", 2], PE: ["PE", "USD", 2], EC: ["EC", "USD", 2],
    DO: ["DO", "USD", 2], TH: ["TH", "USD", 2], CN: ["CN", "USD", 2], ZA: ["ZA", "USD", 2],
    UA: ["UA", "USD", 2], GE: ["GE", "USD", 2], AM: ["AM", "USD", 2], AZ: ["AZ", "USD", 2],
    MK: ["MK", "USD", 2], VN: ["VN", "USD", 1], PH: ["PH", "USD", 1], ID: ["ID", "USD", 1],
    LK: ["LK", "USD", 1], KE: ["KE", "USD", 1], TZ: ["TZ", "USD", 1], UG: ["UG", "USD", 1],
    TR: ["TR", "USD", 1], EG: ["EG", "USD", 1], JO: ["JO", "USD", 1], TN: ["TN", "USD", 1],
    DZ: ["DZ", "USD", 1], NP: ["NP", "USD", 1], KH: ["KH", "USD", 1], LA: ["LA", "USD", 1],
    MM: ["MM", "USD", 1], UZ: ["UZ", "USD", 1], GH: ["GH", "USD", 1], ZM: ["ZM", "USD", 1],
    SN: ["SN", "USD", 1], CI: ["CI", "USD", 1], CM: ["CM", "USD", 1], PK: ["PK", "USD", 0.5],
    BD: ["BD", "USD", 0.5], NG: ["NG", "USD", 0.5], IN: ["India", "INR", 25]
  }
};
