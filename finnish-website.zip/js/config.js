/* Finnish website settings.
   1) DOWNLOAD LINKS: paste each direct download link between the quotes. A button with an empty link
      shows "Download link coming soon" when tapped.
   2) PRICES: the table below applies to the desktop pages. Phone-only overrides go in mobilePrices (India is 25 on the mobile page).
   3) PRICES (continued): edit the amounts per country below (code: [country name, currency code, price per month]). */
window.FINNISH_CONFIG = {
  mobilePrices: { IN: 25 },
  // Annual plan: exact amounts per country where listed, otherwise monthly price x annualMultiple (rounded).
  annual: { mobile: { IN: 200 }, desktop: { IN: 500 } },
  annualMultiple: { mobile: 8, desktop: 10 },
  links: {
    android: "",
    ios: "",
    windows: "",
    mac: "",
    linux: ""
  },
  // DOWNLOAD DETAILS (shown in the Download section). These are SAMPLE values: replace them with the real release details.
  // File size is shown on the Windows, Mac and Linux pages only. The mobile page never shows a size.
  release: {
    version: "1.0.0",
    date: "2026-12-01",
    sizes: { windows: "≈ 90 MB", mac: "≈ 105 MB", linux: "≈ 95 MB" },
    requirements: {
      mobile: "Android 8.0 or later · iOS 14 or later",
      windows: "Windows 10 or 11 · 64-bit",
      mac: "macOS 11 or later",
      linux: "64-bit Linux"
    },
    interface: "8 languages"
  },
  trialDays: 5,
  fallback: ["US", "International", "USD", 5],
  prices: {
    /* — home markets — */
    IN: ["India", "INR", 50],
    US: ["United States", "USD", 5],
    /* — higher-income markets (about US $5) — */
    GB: ["United Kingdom", "GBP", 4], CA: ["Canada", "CAD", 7], AU: ["Australia", "AUD", 8], NZ: ["New Zealand", "NZD", 8],
    IE: ["Ireland", "EUR", 5], DE: ["Germany", "EUR", 5], FR: ["France", "EUR", 5], ES: ["Spain", "EUR", 5], IT: ["Italy", "EUR", 5],
    NL: ["Netherlands", "EUR", 5], BE: ["Belgium", "EUR", 5], AT: ["Austria", "EUR", 5], FI: ["Finland", "EUR", 5], PT: ["Portugal", "EUR", 5],
    CH: ["Switzerland", "CHF", 5], NO: ["Norway", "NOK", 50], SE: ["Sweden", "SEK", 50], DK: ["Denmark", "DKK", 35],
    SG: ["Singapore", "SGD", 7], AE: ["United Arab Emirates", "AED", 19], JP: ["Japan", "JPY", 700], KR: ["South Korea", "KRW", 5900], IL: ["Israel", "ILS", 18],
    /* — middle-income markets (about US $3) — */
    SA: ["Saudi Arabia", "SAR", 12], PL: ["Poland", "PLN", 12], CZ: ["Czechia", "CZK", 69], HU: ["Hungary", "HUF", 1100], RO: ["Romania", "RON", 14],
    TR: ["Türkiye", "TRY", 99], BR: ["Brazil", "BRL", 15], MX: ["Mexico", "MXN", 59], CL: ["Chile", "CLP", 2900], CO: ["Colombia", "COP", 11900],
    MY: ["Malaysia", "MYR", 13], TH: ["Thailand", "THB", 99], ZA: ["South Africa", "ZAR", 49],
    /* — lower-income markets (about US $1.50) — */
    ID: ["Indonesia", "IDR", 25000], PH: ["Philippines", "PHP", 99], VN: ["Vietnam", "VND", 39000], EG: ["Egypt", "EGP", 79], NG: ["Nigeria", "NGN", 1900],
    KE: ["Kenya", "KES", 199], PK: ["Pakistan", "PKR", 399], BD: ["Bangladesh", "BDT", 169], LK: ["Sri Lanka", "LKR", 449], NP: ["Nepal", "NPR", 199]
  }
};
