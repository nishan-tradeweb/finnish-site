/* Finnish website. Creator: Nishan */
(function () {
  'use strict';
  var CFG = window.FINNISH_CONFIG || { links: {}, prices: {}, fallback: ['US', 'International', 'USD', 5], trialDays: 5 };
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- toast ---------- */
  var toastEl = $('#toast'), toastT = 0;
  function toast(msg) {
    if (!toastEl) return; toastEl.textContent = msg; toastEl.classList.add('on');
    clearTimeout(toastT); toastT = setTimeout(function () { toastEl.classList.remove('on'); }, 2400);
  }

  /* ---------- download links (set in js/config.js) ---------- */
  $$('[data-dl]').forEach(function (a) {
    var key = a.getAttribute('data-dl'), url = (CFG.links || {})[key];
    if (url) { a.href = url; a.setAttribute('rel', 'noopener'); }
    else if (key !== 'scroll') {
      a.href = '#download';
      a.addEventListener('click', function (e) { e.preventDefault(); toast('Download link coming soon'); });
    }
  });

  /* ---------- soft, springy download button ---------- */
  function springButton(btn) {
    var st = { px: 0, py: 0, sc: 1, gx: 50, gy: 26, vx: 0, vy: 0, vs: 0, vgx: 0, vgy: 0 };
    var tg = { px: 0, py: 0, sc: 1, gx: 50, gy: 26 };
    var down = false, over = false, raf = 0, K = 0.1, D = 0.80;
    function tick() {
      var keys = [['px', 'vx'], ['py', 'vy'], ['sc', 'vs'], ['gx', 'vgx'], ['gy', 'vgy']], busy = false;
      keys.forEach(function (k) {
        var a = k[0], v = k[1];
        st[v] = (st[v] + (tg[a] - st[a]) * K) * D; st[a] += st[v];
        if (Math.abs(st[v]) > 0.002 || Math.abs(tg[a] - st[a]) > 0.002) busy = true;
      });
      btn.style.setProperty('--px', st.px.toFixed(2) + 'px'); btn.style.setProperty('--py', st.py.toFixed(2) + 'px');
      btn.style.setProperty('--sc', st.sc.toFixed(4));
      btn.style.setProperty('--gx', st.gx.toFixed(1) + '%'); btn.style.setProperty('--gy', st.gy.toFixed(1) + '%');
      raf = busy ? requestAnimationFrame(tick) : 0;
    }
    function go() { if (!raf) raf = requestAnimationFrame(tick); }
    function aim(e) {
      var r = btn.getBoundingClientRect();
      var nx = Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width - .5) * 2));
      var ny = Math.max(-1, Math.min(1, ((e.clientY - r.top) / r.height - .5) * 2));
      var amp = down ? 1.7 : 1;
      tg.px = nx * 4.2 * amp; tg.py = ny * 3 * amp + (down ? 1.6 : 0); tg.gx = 50 + nx * 34; tg.gy = 28 + ny * 24;
    }
    function rest() { tg.px = 0; tg.py = 0; tg.gx = 50; tg.gy = 26; tg.sc = down ? .955 : (over ? 1.015 : 1); }
    if (reduce) return;
    btn.addEventListener('pointerenter', function (e) { over = true; tg.sc = down ? .955 : 1.015; aim(e); go(); });
    btn.addEventListener('pointermove', function (e) { aim(e); go(); });
    btn.addEventListener('pointerleave', function () { over = false; down = false; rest(); go(); });
    btn.addEventListener('pointerdown', function (e) { down = true; tg.sc = .955; aim(e); go(); });
    window.addEventListener('pointerup', function () { if (!down) return; down = false; rest(); go(); });
    btn.addEventListener('pointercancel', function () { down = false; over = false; rest(); go(); });
    btn.addEventListener('contextmenu', function (e) { if (e.pointerType === 'touch') e.preventDefault(); });
  }
  $$('.dl').forEach(springButton);

  /* ---------- nav shadow, reveal ---------- */
  var nav = $('.nav');
  function onScroll() { nav.classList.toggle('stuck', window.scrollY > 24); }
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: .12, rootMargin: '0px 0px -6% 0px' });
    $$('.reveal').forEach(function (n) { io.observe(n); });
  } else { $$('.reveal').forEach(function (n) { n.classList.add('in'); }); }

  /* ---------- theme switch ---------- */
  var stage = $('#stage'), tgl = $('#themeTg');
  function setTheme(black) {
    stage.setAttribute('data-theme', black ? 'black' : 'white');
    tgl.setAttribute('aria-checked', black ? 'true' : 'false');
    tgl.setAttribute('aria-label', black ? 'Switch preview to Matte White' : 'Switch preview to Matte Black');
  }
  if (stage && tgl) {
    tgl.addEventListener('click', function () { setTheme(tgl.getAttribute('aria-checked') !== 'true'); });
    $$('.tg-lab').forEach(function (l) { l.addEventListener('click', function () { setTheme(l.getAttribute('data-for') === 'black'); }); });
  }

  /* ---------- pricing by country ---------- */
  var TZ = {
    'Asia/Kolkata': 'IN', 'Asia/Calcutta': 'IN', 'Europe/London': 'GB', 'Europe/Dublin': 'IE', 'Europe/Berlin': 'DE', 'Europe/Paris': 'FR', 'Europe/Madrid': 'ES',
    'Europe/Rome': 'IT', 'Europe/Amsterdam': 'NL', 'Europe/Brussels': 'BE', 'Europe/Vienna': 'AT', 'Europe/Helsinki': 'FI', 'Europe/Lisbon': 'PT', 'Europe/Zurich': 'CH',
    'Europe/Oslo': 'NO', 'Europe/Stockholm': 'SE', 'Europe/Copenhagen': 'DK', 'Europe/Warsaw': 'PL', 'Europe/Prague': 'CZ', 'Europe/Budapest': 'HU', 'Europe/Bucharest': 'RO',
    'Europe/Istanbul': 'TR', 'Asia/Istanbul': 'TR', 'Asia/Singapore': 'SG', 'Asia/Dubai': 'AE', 'Asia/Tokyo': 'JP', 'Asia/Seoul': 'KR', 'Asia/Jerusalem': 'IL', 'Asia/Riyadh': 'SA',
    'Pacific/Auckland': 'NZ', 'America/Sao_Paulo': 'BR', 'America/Mexico_City': 'MX', 'America/Santiago': 'CL', 'America/Bogota': 'CO', 'Asia/Kuala_Lumpur': 'MY',
    'Asia/Bangkok': 'TH', 'Africa/Johannesburg': 'ZA', 'Asia/Jakarta': 'ID', 'Asia/Manila': 'PH', 'Asia/Ho_Chi_Minh': 'VN', 'Asia/Saigon': 'VN', 'Africa/Cairo': 'EG',
    'Africa/Lagos': 'NG', 'Africa/Nairobi': 'KE', 'Asia/Karachi': 'PK', 'Asia/Dhaka': 'BD', 'Asia/Colombo': 'LK', 'Asia/Kathmandu': 'NP', 'Asia/Katmandu': 'NP'
  };
  function regionFromTz() {
    var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) { }
    if (TZ[tz]) return TZ[tz];
    if (/^Australia\//.test(tz)) return 'AU';
    if (/^America\/(Toronto|Vancouver|Edmonton|Winnipeg|Halifax|St_Johns|Regina|Montreal|Moncton|Glace_Bay|Iqaluit|Whitehorse|Yellowknife)/.test(tz)) return 'CA';
    if (/^America\/(New_York|Chicago|Denver|Los_Angeles|Phoenix|Anchorage|Boise|Detroit|Indiana|Kentucky|Menominee|North_Dakota|Juneau|Adak|Sitka|Nome|Yakutat|Metlakatla)/.test(tz) || tz === 'Pacific/Honolulu') return 'US';
    return '';
  }
  function regionFromLang() {
    var l = (navigator.languages && navigator.languages[0]) || navigator.language || '', m = l.match(/[-_]([A-Za-z]{2})$/);
    return m ? m[1].toUpperCase() : '';
  }
  function money(cur, amt) {
    try { return new Intl.NumberFormat('en', { style: 'currency', currency: cur, maximumFractionDigits: 0, minimumFractionDigits: 0 }).format(amt); }
    catch (e) { return cur + ' ' + amt; }
  }
  var priceEl = $('#priceNum'), sel = $('#regionSel');
  if (priceEl && sel) {
    var P = CFG.prices || {}, fb = CFG.fallback;
    var codes = Object.keys(P).sort(function (a, b) { return P[a][0].localeCompare(P[b][0]); });
    codes.forEach(function (c) { var o = document.createElement('option'); o.value = c; o.textContent = P[c][0]; sel.appendChild(o); });
    var oo = document.createElement('option'); oo.value = 'ZZ'; oo.textContent = 'Other countries'; sel.appendChild(oo);
    var saved = ''; try { saved = localStorage.getItem('fn-region') || ''; } catch (e) { }
    var start = saved || regionFromTz() || (P[regionFromLang()] ? regionFromLang() : '') || 'ZZ';
    if (start !== 'ZZ' && !P[start]) start = 'ZZ';
    function show(code) {
      var row = code === 'ZZ' ? fb : [code, P[code][0], P[code][1], P[code][2]];
      var cur = code === 'ZZ' ? fb[2] : P[code][1], amt = code === 'ZZ' ? fb[3] : P[code][2];
      priceEl.textContent = money(cur, amt); sel.value = code;
    }
    show(start);
    sel.addEventListener('change', function () { show(sel.value); try { localStorage.setItem('fn-region', sel.value); } catch (e) { } });
  }

  var y = $('#yr'); if (y) y.textContent = new Date().getFullYear();
})();
