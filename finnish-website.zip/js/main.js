/* Finnish website. Creator: Nishan */
(function () {
  'use strict';
  var CFG = { owner: 'gazaldarbar', repo: 'finnish', web: 'https://gazaldarbar.github.io/finnish/' };
  var RELEASES_PAGE = 'https://github.com/' + CFG.owner + '/' + CFG.repo + '/releases';
  var API = 'https://api.github.com/repos/' + CFG.owner + '/' + CFG.repo + '/releases?per_page=20';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- soft, springy download button ---------- */
  function springButton(btn) {
    var puff = $('.dl-puff', btn);
    var st = { px: 0, py: 0, sc: 1, gx: 50, gy: 26, vx: 0, vy: 0, vs: 0, vgx: 0, vgy: 0 };
    var tg = { px: 0, py: 0, sc: 1, gx: 50, gy: 26 };
    var down = false, over = false, raf = 0;
    var K = 0.1, D = 0.80; // stiffness / damping: soft with a little wobble

    function tick() {
      var keys = [['px', 'vx'], ['py', 'vy'], ['sc', 'vs'], ['gx', 'vgx'], ['gy', 'vgy']];
      var busy = false;
      keys.forEach(function (k) {
        var a = k[0], v = k[1];
        st[v] = (st[v] + (tg[a] - st[a]) * K) * D;
        st[a] += st[v];
        if (Math.abs(st[v]) > 0.002 || Math.abs(tg[a] - st[a]) > 0.002) busy = true;
      });
      btn.style.setProperty('--px', st.px.toFixed(2) + 'px');
      btn.style.setProperty('--py', st.py.toFixed(2) + 'px');
      btn.style.setProperty('--sc', st.sc.toFixed(4));
      btn.style.setProperty('--gx', st.gx.toFixed(1) + '%');
      btn.style.setProperty('--gy', st.gy.toFixed(1) + '%');
      raf = busy ? requestAnimationFrame(tick) : 0;
    }
    function go() { if (!raf) raf = requestAnimationFrame(tick); }

    function aim(e) {
      var r = btn.getBoundingClientRect();
      var nx = Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width - .5) * 2));
      var ny = Math.max(-1, Math.min(1, ((e.clientY - r.top) / r.height - .5) * 2));
      var amp = down ? 1.7 : 1;
      tg.px = nx * 4.2 * amp; tg.py = ny * 3 * amp + (down ? 1.6 : 0);
      tg.gx = 50 + nx * 34; tg.gy = 28 + ny * 24;
    }
    function rest() {
      tg.px = 0; tg.py = 0; tg.gx = 50; tg.gy = 26;
      tg.sc = down ? .955 : (over ? 1.015 : 1);
    }

    if (reduce) return;
    btn.addEventListener('pointerenter', function (e) { over = true; tg.sc = down ? .955 : 1.015; aim(e); go(); });
    btn.addEventListener('pointermove', function (e) { aim(e); go(); });
    btn.addEventListener('pointerleave', function () { over = false; down = false; rest(); go(); });
    btn.addEventListener('pointerdown', function (e) { down = true; tg.sc = .955; aim(e); go(); });
    window.addEventListener('pointerup', function () { if (!down) return; down = false; rest(); go(); });
    btn.addEventListener('pointercancel', function () { down = false; over = false; rest(); go(); });
    btn.addEventListener('contextmenu', function (e) { if (e.pointerType === 'touch') e.preventDefault(); });
  }
  $$('.dl').forEach(springButton);

  /* ---------- nav shadow, reveal on scroll ---------- */
  var nav = $('.nav');
  function onScroll() { nav.classList.toggle('stuck', window.scrollY > 24); }
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: .12, rootMargin: '0px 0px -6% 0px' });
    $$('.reveal').forEach(function (n) { io.observe(n); });
  } else { $$('.reveal').forEach(function (n) { n.classList.add('in'); }); }

  /* ---------- theme switch (Matte White / Matte Black) ---------- */
  var stage = $('#stage'), tgl = $('#themeTg');
  function setTheme(black) {
    stage.setAttribute('data-theme', black ? 'black' : 'white');
    tgl.setAttribute('aria-checked', black ? 'true' : 'false');
    tgl.setAttribute('aria-label', black ? 'Switch preview to Matte White' : 'Switch preview to Matte Black');
  }
  tgl.addEventListener('click', function () { setTheme(tgl.getAttribute('aria-checked') !== 'true'); });
  $$('.tg-lab').forEach(function (l) { l.style.cursor = 'pointer'; l.addEventListener('click', function () { setTheme(l.getAttribute('data-for') === 'black'); }); });

  /* ---------- OS detection ---------- */
  function detectOS() {
    var ua = navigator.userAgent || '', pf = (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '';
    if (/iPhone|iPad|iPod/.test(ua) || (/Mac/.test(pf) && navigator.maxTouchPoints > 1)) return 'ios';
    if (/Android/i.test(ua)) return 'android';
    if (/Win/i.test(pf) || /Windows/.test(ua)) return 'win';
    if (/Mac/i.test(pf) || /Mac OS X/.test(ua)) return 'mac';
    if (/Linux|X11|CrOS/i.test(pf + ua)) return 'linux';
    return 'win';
  }
  var OS = detectOS();
  var OSNAME = { win: 'Windows', mac: 'macOS', linux: 'Linux', android: 'Android', ios: 'iOS' };
  var REQ = { win: 'Windows 10/11 · 64-bit', mac: 'macOS 11+ · Apple silicon & Intel', linux: '64-bit · AppImage or .deb', android: 'Android APK' };

  var heroDl = $('#heroDl'), heroOs = $('#heroDlOs'), heroMeta = $('#heroMeta'), heroChip = $('#heroChip');
  if (OS === 'ios') { heroOs.textContent = 'desktop app'; heroMeta.textContent = 'On iPhone or iPad, use the browser version'; }
  else { heroOs.textContent = 'for ' + OSNAME[OS]; }
  var hl = $('[data-platform="' + OS + '"]'); if (hl) hl.classList.add('hl');

  /* ---------- releases from GitHub ---------- */
  function mb(n) { return n ? (n / 1048576 >= 10 ? Math.round(n / 1048576) : (n / 1048576).toFixed(1)) + ' MB' : ''; }
  function ver(a, r) { var m = (a.name || '').match(/(\d+\.\d+\.\d+)/); return m ? m[1] : (r.tag_name || '').replace(/^v/, ''); }
  function pick(releases) {
    var out = { win: {}, mac: {}, linux: {}, android: {} };
    var rules = [
      ['win', 'main', /setup.*\.exe$/i], ['win', 'portable', /portable.*\.exe$/i], ['win', 'main', /\.exe$/i],
      ['mac', 'arm', /\.dmg$/i, /arm64|aarch64/i], ['mac', 'intel', /\.dmg$/i, /x64|x86_64|intel/i], ['mac', 'main', /\.dmg$/i],
      ['linux', 'main', /\.AppImage$/i], ['linux', 'deb', /\.deb$/i],
      ['android', 'main', /\.apk$/i]
    ];
    releases.forEach(function (r) {
      if (r.draft) return;
      (r.assets || []).forEach(function (a) {
        rules.forEach(function (ru) {
          if (!ru[2].test(a.name)) return;
          if (ru[3] && !ru[3].test(a.name)) return;
          var slot = out[ru[0]]; var cur = slot[ru[1]];
          if (!cur || new Date(a.updated_at || r.published_at) > new Date(cur.when)) {
            slot[ru[1]] = { url: a.browser_download_url, name: a.name, size: a.size, version: ver(a, r), when: a.updated_at || r.published_at };
          }
        });
      });
    });
    return out;
  }
  function link(item, label) { return '<a href="' + item.url + '">' + label + '</a>'; }

  function apply(data) {
    var any = false;
    ['win', 'mac', 'linux'].forEach(function (p) {
      var card = $('[data-platform="' + p + '"]'); if (!card) return;
      var d = data[p], main = d.main || d.arm || d.intel;
      var btn = $('[data-primary]', card), meta = $('[data-meta]', card), alts = $('[data-alts]', card);
      if (!main) { btn.href = RELEASES_PAGE; meta.textContent = 'Latest builds on GitHub Releases'; return; }
      any = true;
      var primary = p === 'mac' ? (d.arm || main) : main;
      btn.href = primary.url; btn.setAttribute('download', '');
      meta.textContent = ['v' + primary.version, mb(primary.size)].filter(Boolean).join(' · ');
      var a = [];
      if (p === 'win' && d.portable) a.push(link(d.portable, 'Portable .exe'));
      if (p === 'mac') { if (d.arm) a.push(link(d.arm, 'Apple silicon')); if (d.intel) a.push(link(d.intel, 'Intel')); }
      if (p === 'linux' && d.deb) a.push(link(d.deb, '.deb package'));
      alts.innerHTML = a.join('');
    });
    if (data.android.main) { var ab = $('[data-also=android]'); ab.href = data.android.main.url; }

    var chosen = data[OS] && (data[OS].main || data[OS].arm);
    if (OS === 'ios') { heroDl.href = CFG.web; }
    else if (chosen) {
      var primaryH = OS === 'mac' ? (data.mac.arm || chosen) : chosen;
      heroDl.href = primaryH.url; heroDl.setAttribute('download', '');
      heroMeta.textContent = 'v' + primaryH.version + (primaryH.size ? ' · ' + mb(primaryH.size) : '') + ' · ' + REQ[OS] + ' · Free';
      heroChip.textContent = 'Version ' + primaryH.version + ' · ' + 'Windows · macOS · Linux';
    } else {
      heroDl.href = '#download';
      heroMeta.textContent = REQ[OS] + ' · Free';
    }
    var any_v = (data.win.main || data.linux.main || data.mac.arm || {}).version;
    if (any_v) $('#ver').textContent = 'Version ' + any_v;
  }

  var cached = null;
  try { cached = JSON.parse(sessionStorage.getItem('fn-rel') || 'null'); } catch (e) { }
  if (cached && Date.now() - cached.t < 10 * 60 * 1000) { apply(cached.d); }
  else if (window.fetch) {
    fetch(API, { headers: { Accept: 'application/vnd.github+json' } })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(function (list) {
        var d = pick(list); apply(d);
        try { sessionStorage.setItem('fn-rel', JSON.stringify({ t: Date.now(), d: d })); } catch (e) { }
      })
      .catch(function () {
        $$('[data-primary]').forEach(function (b) { b.href = RELEASES_PAGE; });
        heroDl.href = '#download';
      });
  }
  $('#yr').textContent = new Date().getFullYear();
})();
